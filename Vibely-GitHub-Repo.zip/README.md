<div align="center">
  <img src="github-assets/vibely-logo.png" alt="Vibely Logo" width="120" height="120">
  
  <h1 align="center">Vibely</h1>
  
  <p align="center">
    <strong>A Modern Social Media Platform</strong>
    <br />
    <em>Share Your Vibes. Connect With The World.</em>
  </p>
  
  <p align="center">
    <a href="#features">Features</a> •
    <a href="#demo">Demo</a> •
    <a href="#tech-stack">Tech Stack</a> •
    <a href="#getting-started">Getting Started</a> •
    <a href="#contributing">Contributing</a>
  </p>
  
  <br/>
  
  <img src="github-assets/vibely-banner.png" alt="Vibely Banner" width="100%">
</div>

---

<div align="center">

[![Next.js](https://img.shields.io/badge/Next.js-15.5.9-000000?style=for-the-badge&logo=next.js&logoColor=white)](https://nextjs.org/)
[![React](https://img.shields.io/badge/React-19.2.1-61DAFB?style=for-the-badge&logo=react&logoColor=black)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6?style=for-the-badge&logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-3.4-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)](https://tailwindcss.com/)
[![Firebase](https://img.shields.io/badge/Firebase-11.9-FFCA28?style=for-the-badge&logo=firebase&logoColor=black)](https://firebase.google.com/)
[![Genkit AI](https://img.shields.io/badge/Genkit_AI-1.28-4285F4?style=for-the-badge&logo=google&logoColor=white)](https://genkit.dev/)

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg?style=for-the-badge)](LICENSE)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=for-the-badge)](CONTRIBUTING.md)
[![Made with Love](https://img.shields.io/badge/Made%20with-❤️-red.svg?style=for-the-badge)](https://github.com/laxmanmeghwaltech-svg)

</div>

---

## 📱 About

**Vibely** is a full-featured social media platform that combines the best elements from today's most popular social apps. From text posts and short-form videos to stories and real-time messaging, Vibely offers a unified, seamless social experience powered by modern web technologies and AI.

> 🚀 **This is my first major project** — built to learn, experiment, and create something meaningful. Every feature was implemented with passion and a desire to understand modern web development.

---

## ✨ Features

<table>
<tr>
<td width="50%">

### 🔐 Authentication & Profiles
- Secure sign-up & login with Firebase Auth
- Customizable user profiles
- Avatar upload & bio management
- Social metrics dashboard

</td>
<td width="50%">

### 📝 Content Creation
- Text-based posts (like X/Twitter)
- Short-form videos (like Reels/TikTok)
- AI-powered caption suggestions
- Media upload to cloud storage

</td>
</tr>
<tr>
<td width="50%">

### 📱 Stories
- Ephemeral content sharing
- Episodic storytelling format
- Story bundles with multiple clips
- 24-hour visibility

</td>
<td width="50%">

### 📰 Personalized Feed
- Infinite scrolling experience
- "For You" AI recommendations
- "Following" tab for subscribed users
- Mix of text and video content

</td>
</tr>
<tr>
<td width="50%">

### 💬 Engagement
- Like, comment, and save posts
- Share content with others
- Real-time notifications
- Direct messaging

</td>
<td width="50%">

### 🤖 AI-Powered Features
- Smart caption generation
- Personalized feed recommendations
- AI comment suggestions
- Content analysis

</td>
</tr>
</table>

---

## 🎬 Demo

> Screenshots coming soon!

| Home Feed | Stories | Profile |
|-----------|---------|---------|
| *Feed screenshot* | *Stories screenshot* | *Profile screenshot* |

| Messages | Notifications | Explore |
|----------|---------------|---------|
| *Messages screenshot* | *Notifications screenshot* | *Explore screenshot* |

---

## 🏗️ Tech Stack

### Frontend
| Technology | Purpose |
|------------|---------|
| ![Next.js](https://img.shields.io/badge/Next.js-15.5.9-black?style=flat-square&logo=next.js) | React framework with App Router |
| ![React](https://img.shields.io/badge/React-19.2.1-61DAFB?style=flat-square&logo=react) | UI library |
| ![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6?style=flat-square&logo=typescript) | Type safety |
| ![Tailwind](https://img.shields.io/badge/Tailwind_CSS-3.4-38B2AC?style=flat-square&logo=tailwind-css) | Styling |
| ![shadcn/ui](https://img.shields.io/badge/shadcn/ui-latest-black?style=flat-square) | UI components |

### Backend & Services
| Technology | Purpose |
|------------|---------|
| ![Firebase](https://img.shields.io/badge/Firebase-11.9-FFCA28?style=flat-square&logo=firebase) | Authentication, Database, Storage |
| ![Firestore](https://img.shields.io/badge/Firestore-Latest-FFCA28?style=flat-square&logo=firebase) | NoSQL database |
| ![Genkit](https://img.shields.io/badge/Genkit_AI-1.28-4285F4?style=flat-square&logo=google) | AI integration framework |

### Development Tools
| Tool | Purpose |
|------|---------|
| ESLint | Code linting |
| TypeScript | Static typing |
| PostCSS | CSS processing |

---

## 📁 Project Structure

```
vibely/
├── 📂 src/
│   ├── 📂 app/                    # Next.js App Router pages
│   │   ├── 📄 page.tsx           # 🏠 Home feed
│   │   ├── 📂 profile/           # 👤 User profile
│   │   ├── 📂 stories/           # 📱 Stories feature
│   │   ├── 📂 shorts/            # 🎬 Short-form videos
│   │   ├── 📂 videos/            # 🎥 Long-form videos
│   │   ├── 📂 messages/          # 💬 Direct messaging
│   │   ├── 📂 notifications/     # 🔔 Notifications
│   │   └── 📂 explore/           # 🔍 Discover content
│   │
│   ├── 📂 components/            # 🧩 Reusable components
│   │   ├── 📂 ui/               # shadcn/ui components
│   │   ├── 📂 feed/             # Feed-related components
│   │   ├── 📂 stories/          # Story viewer components
│   │   ├── 📂 create/           # Post creation modal
│   │   └── 📂 layout/           # Layout & navigation
│   │
│   ├── 📂 ai/                    # 🤖 AI flows (Genkit)
│   │   ├── 📂 flows/
│   │   │   ├── 📄 ai-post-caption-generator.ts
│   │   │   ├── 📄 ai-personalized-feed-recommendations.ts
│   │   │   └── 📄 ai-comment-suggestions.ts
│   │   └── 📄 genkit.ts         # Genkit configuration
│   │
│   ├── 📂 firebase/              # 🔥 Firebase integration
│   │   ├── 📄 config.ts         # Firebase config
│   │   ├── 📂 auth/             # Auth hooks
│   │   └── 📂 firestore/        # Database hooks
│   │
│   ├── 📂 hooks/                 # 🪝 Custom React hooks
│   └── 📂 lib/                   # 📚 Utilities & helpers
│
├── 📂 docs/                      # 📖 Documentation
├── 📂 .github/                   # 🐙 GitHub templates
├── 📄 .env.example               # 🔑 Environment template
├── 📄 package.json               # 📦 Dependencies
└── 📄 README.md                  # 📄 You are here
```

---

## 🚀 Getting Started

### Prerequisites

Make sure you have the following installed:

- ![Node.js](https://img.shields.io/badge/Node.js-18+-green?style=flat-square&logo=node.js) 
- ![npm](https://img.shields.io/badge/npm-latest-red?style=flat-square) or ![yarn](https://img.shields.io/badge/yarn-latest-blue?style=flat-square)
- ![Git](https://img.shields.io/badge/Git-latest-orange?style=flat-square&logo=git)

### Firebase Setup

1. Create a new project on [Firebase Console](https://console.firebase.google.com/)
2. Enable **Authentication** (Email/Password)
3. Create a **Firestore Database**
4. Set up **Storage** for media uploads
5. Get your Firebase config from Project Settings

### Installation

```bash
# 1️⃣ Clone the repository
git clone https://github.com/laxmanmeghwaltech-svg/Vibely.git

# 2️⃣ Navigate to the project
cd Vibely

# 3️⃣ Install dependencies
npm install

# 4️⃣ Copy environment template
cp .env.example .env.local

# 5️⃣ Add your credentials to .env.local
# (See Environment Variables section below)

# 6️⃣ Start development server
npm run dev
```

### Environment Variables

Create a `.env.local` file with the following:

```env
# Firebase Configuration
NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id

# Google AI (for Genkit features)
GOOGLE_GENAI_API_KEY=your_google_ai_api_key
```

### Run the App

```bash
# Development mode with Turbopack
npm run dev

# Production build
npm run build

# Start production server
npm start
```

Open [http://localhost:9002](http://localhost:9002) in your browser.

---

## 📜 Available Scripts

| Script | Description |
|--------|-------------|
| `npm run dev` | 🧑‍💻 Start dev server with Turbopack (port 9002) |
| `npm run build` | 🏗️ Build for production |
| `npm run start` | 🚀 Start production server |
| `npm run lint` | 🔍 Run ESLint |
| `npm run typecheck` | ✅ Run TypeScript type checking |
| `npm run genkit:dev` | 🤖 Start Genkit AI development server |
| `npm run genkit:watch` | 👀 Start Genkit with hot reload |

---

## 🎨 Design System

### Colors

| Color | Hex | Preview | Usage |
|-------|-----|---------|-------|
| Primary | `#24248F` | ![#24248F](https://via.placeholder.com/20/24248F/24248F) | Brand color, headers |
| Accent | `#8C30E8` | ![#8C30E8](https://via.placeholder.com/20/8C30E8/8C30E8) | CTAs, interactive elements |
| Background | `#F0F0F4` | ![#F0F0F4](https://via.placeholder.com/20/F0F0F4/F0F0F4) | Page backgrounds |

### Typography

- **Font Family**: [Inter](https://fonts.google.com/specimen/Inter)
- **Style**: Modern, minimal, highly readable
- **Weights**: 400 (Regular), 500 (Medium), 600 (Semi-bold), 700 (Bold)

---

## 🗺️ Roadmap

- [ ] 🎥 Video upload and processing with Cloud Functions
- [ ] 🔔 Push notifications
- [ ] 📅 Post scheduling
- [ ] 📊 Advanced analytics dashboard
- [ ] 🛡️ Content moderation tools
- [ ] 🌍 Multi-language support (i18n)
- [ ] 🌙 Dark mode
- [ ] 📱 PWA support
- [ ] 🔗 OAuth providers (Google, Apple)
- [ ] 💳 Premium features & subscriptions

---

## 🤝 Contributing

Contributions are what make the open source community such an amazing place to learn, inspire, and create. Any contributions you make are **greatly appreciated**!

Please see the [Contributing Guide](CONTRIBUTING.md) for detailed instructions.

### Quick Steps

1. 🍴 Fork the repository
2. 🌿 Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. 💾 Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. 📤 Push to the branch (`git push origin feature/AmazingFeature`)
5. 📝 Open a Pull Request

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 👤 Author

<div align="center">

<img src="https://avatars.githubusercontent.com/u/your-username" width="100" height="100" style="border-radius: 50%;">

**Laxman Meghwal**

[![GitHub](https://img.shields.io/badge/GitHub-laxmanmeghwaltech--svg-181717?style=for-the-badge&logo=github)](https://github.com/laxmanmeghwaltech-svg)

</div>

---

## 🙏 Acknowledgments

Special thanks to these amazing projects and communities:

- [Next.js](https://nextjs.org/) - The React Framework for Production
- [Firebase](https://firebase.google.com/) - Backend as a Service
- [shadcn/ui](https://ui.shadcn.com/) - Beautiful, accessible UI components
- [Tailwind CSS](https://tailwindcss.com/) - Utility-first CSS framework
- [Lucide Icons](https://lucide.dev/) - Beautiful open-source icons
- [Genkit](https://genkit.dev/) - Build AI-powered applications

---

<div align="center">

### ⭐ If you found this project useful, please consider giving it a star!

[![Star History Chart](https://api.star-history.com/svg?repos=laxmanmeghwaltech-svg/Vibely&type=Date)](https://star-history.com/#laxmanmeghwaltech-svg/Vibely&Date)

**Made with ❤️ by Laxman Meghwal**

*This is my first major open-source project. Feedback and suggestions are always welcome!*

</div>
