# Security Policy

## 🔒 Security Overview

The security of Vibely and its users is a top priority. We appreciate your efforts to responsibly disclose vulnerabilities and will make every effort to acknowledge your contributions.

## 📋 Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | :white_check_mark: Active development |
| < 0.1   | :x: Not released   |

## 🚨 Reporting a Vulnerability

We take all security vulnerabilities seriously. If you believe you have found a vulnerability, please report it to us as described below.

### How to Report

**Please do NOT report security vulnerabilities through public GitHub issues.**

Instead, please report them via one of the following methods:

1. **GitHub Security Advisory** (Preferred)
   - Go to the [Security tab](https://github.com/laxmanmeghwaltech-svg/Vibely/security)
   - Click "Report a vulnerability"
   - Fill in the details of the vulnerability

2. **Email**
   - Send an email to the project maintainer
   - Include "SECURITY VULNERABILITY" in the subject line

### What to Include

Please include the following information in your report:

- **Description** of the vulnerability
- **Steps to reproduce** the issue
- **Potential impact** of the vulnerability
- **Possible solutions** (if you have any)
- Your **contact information** for follow-up

### Response Timeline

| Action | Expected Timeframe |
|--------|-------------------|
| Initial response | Within 48 hours |
| Vulnerability confirmation | Within 7 days |
| Fix development | Depends on severity |
| Patch release | As soon as possible |

## 🛡️ Security Best Practices

When using Vibely, please follow these security best practices:

### For Developers

- **Never commit sensitive data** - Always use `.env.local` for secrets
- **Keep dependencies updated** - Run `npm audit` regularly
- **Use environment variables** - Never hardcode API keys or credentials
- **Enable Firebase security rules** - Protect your database and storage
- **Validate user input** - Always sanitize and validate incoming data

### For Users

- **Use strong passwords** - At least 12 characters with mixed types
- **Enable 2FA** - When available, enable two-factor authentication
- **Review permissions** - Check what data apps can access
- **Report suspicious activity** - Let us know if something seems off

## 🔐 Security Features

Vibely implements the following security measures:

- **Firebase Authentication** - Secure user authentication
- **Firestore Security Rules** - Database access control
- **Storage Security Rules** - File access control
- **Input Validation** - Server-side validation of user inputs
- **Environment Variables** - Secrets are never exposed to client
- **HTTPS Only** - All communications are encrypted
- **Content Security Policy** - XSS protection

## ⚠️ Known Security Considerations

### Firebase Configuration

The Firebase configuration object (`firebaseConfig`) is visible in the client-side code. This is by design and is safe because:

- Firebase config is meant to be public
- Security is enforced through Firebase Security Rules
- Authentication is required for sensitive operations

**Important:** Always configure proper security rules in Firebase Console!

### Environment Variables

The following environment variables are exposed to the client (prefixed with `NEXT_PUBLIC_`):

- `NEXT_PUBLIC_FIREBASE_API_KEY`
- `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`
- `NEXT_PUBLIC_FIREBASE_PROJECT_ID`
- `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET`
- `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`
- `NEXT_PUBLIC_FIREBASE_APP_ID`

These are safe to expose as they are configuration values, not secrets.

### Secrets (Never Exposed)

These environment variables should **NEVER** be prefixed with `NEXT_PUBLIC_`:

- `GOOGLE_GENAI_API_KEY` - AI API key
- Any service account credentials

## 📚 Security Resources

- [Firebase Security Rules](https://firebase.google.com/docs/rules)
- [Next.js Security](https://nextjs.org/docs/app/building-your-application/configuring/content-security-policy)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)

## 🙏 Acknowledgments

We would like to thank all security researchers and contributors who help keep Vibely secure. Your responsible disclosure helps protect our users.

---

*Last updated: January 2025*
