# Contributing to Vibely

First off, thank you for considering contributing to Vibely! It's people like you that make Vibely such a great tool. This is my first open-source project, and I'm excited to have you on board.

## 📜 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How Can I Contribute?](#how-can-i-contribute)
- [Development Setup](#development-setup)
- [Project Structure](#project-structure)
- [Coding Standards](#coding-standards)
- [Commit Guidelines](#commit-guidelines)
- [Pull Request Process](#pull-request-process)

---

## 🤝 Code of Conduct

This project and everyone participating in it is governed by our [Code of Conduct](CODE_OF_CONDUCT.md). By participating, you are expected to uphold this code. Please report unacceptable behavior to the project maintainer.

---

## 🙋 How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check the existing issues as you might find out that you don't need to create one. When you are creating a bug report, please include as many details as possible:

- **Use a clear and descriptive title**
- **Describe the exact steps to reproduce the problem**
- **Provide specific examples to demonstrate the steps**
- **Describe the behavior you observed and what you expected**
- **Include screenshots or animated GIFs if helpful**
- **Include your environment details** (OS, browser, Node.js version)

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion:

- **Use a clear and descriptive title**
- **Provide a step-by-step description of the suggested enhancement**
- **Provide specific examples to demonstrate the steps**
- **Describe the current behavior and explain the expected behavior**
- **Explain why this enhancement would be useful**

### Pull Requests

- Fill in the required template
- Do not include issue numbers in the title
- Include screenshots and animated GIFs in your pull request whenever possible
- Follow the coding standards
- Document new code based on the Documentation Styleguide

---

## 🛠️ Development Setup

### Prerequisites

- Node.js 18+
- npm or yarn
- Git
- A Firebase project
- Google AI API key (for Genkit features)

### Setting Up Your Development Environment

1. **Fork and clone the repository**
   ```bash
   git clone https://github.com/YOUR_USERNAME/Vibely.git
   cd Vibely
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env.local
   ```
   Then fill in your Firebase and API credentials.

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Create a branch for your changes**
   ```bash
   git checkout -b feature/your-feature-name
   ```

---

## 📁 Project Structure

Understanding the project structure will help you navigate and contribute effectively:

```
src/
├── app/              # Next.js App Router pages
├── components/       # Reusable React components
│   ├── ui/          # Base UI components (shadcn)
│   ├── feed/        # Feed-related components
│   ├── stories/     # Story feature components
│   ├── create/      # Content creation components
│   └── layout/      # Layout and navigation
├── ai/              # Genkit AI flows
├── firebase/        # Firebase configuration and hooks
├── hooks/           # Custom React hooks
└── lib/             # Utility functions and helpers
```

---

## 💻 Coding Standards

### TypeScript

- Use TypeScript for all new files
- Define proper types and interfaces
- Avoid using `any` type when possible
- Use meaningful variable and function names

### React

- Use functional components with hooks
- Follow the single responsibility principle
- Keep components small and focused
- Use proper prop typing with TypeScript interfaces

### Styling

- Use Tailwind CSS utility classes
- Follow the existing color palette and design system
- Ensure responsive design (mobile-first approach)
- Use the `cn()` utility for conditional class names

### Example Component Structure

```tsx
"use client";

import React from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface MyComponentProps {
  title: string;
  onClick?: () => void;
  variant?: 'primary' | 'secondary';
}

export function MyComponent({ 
  title, 
  onClick, 
  variant = 'primary' 
}: MyComponentProps) {
  return (
    <div className="p-4 rounded-lg bg-card">
      <h2 className="text-lg font-semibold">{title}</h2>
      <Button 
        onClick={onClick}
        className={cn(
          "mt-2",
          variant === 'primary' && "bg-primary",
          variant === 'secondary' && "bg-secondary"
        )}
      >
        Click me
      </Button>
    </div>
  );
}
```

---

## 📝 Commit Guidelines

We follow conventional commit messages for clarity and consistency:

### Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types

| Type | Description |
|------|-------------|
| `feat` | A new feature |
| `fix` | A bug fix |
| `docs` | Documentation only changes |
| `style` | Changes that do not affect the meaning of the code |
| `refactor` | A code change that neither fixes a bug nor adds a feature |
| `perf` | A code change that improves performance |
| `test` | Adding missing tests or correcting existing tests |
| `chore` | Changes to the build process or auxiliary tools |

### Examples

```bash
feat(feed): add infinite scroll to home feed
fix(auth): resolve login redirect issue
docs(readme): update installation instructions
style(button): improve hover animation
refactor(firebase): optimize Firestore queries
```

---

## 🔄 Pull Request Process

1. **Update Documentation** - Ensure your changes are documented
2. **Add Tests** - If applicable, add tests for your changes
3. **Follow Code Style** - Run `npm run lint` to check for issues
4. **Type Check** - Run `npm run typecheck` to ensure type safety
5. **Update CHANGELOG** - Add your changes to the changelog
6. **Request Review** - Request a review from maintainers

### PR Checklist

- [ ] My code follows the coding standards of this project
- [ ] I have performed a self-review of my own code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests pass locally with my changes

---

## 🆘 Need Help?

If you have any questions or need help, feel free to:

- Open a [Discussion](https://github.com/laxmanmeghwaltech-svg/Vibely/discussions)
- Create an [Issue](https://github.com/laxmanmeghwaltech-svg/Vibely/issues)
- Reach out to the maintainer

---

## 📜 License

By contributing to Vibely, you agree that your contributions will be licensed under the MIT License.

---

Thank you for contributing! 🎉
