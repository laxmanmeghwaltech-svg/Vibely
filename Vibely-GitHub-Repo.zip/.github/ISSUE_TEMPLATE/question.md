---
name: Question
about: Ask a question about Vibely
title: '[QUESTION] '
labels: question
assignees: ''
---

## ❓ Question

A clear and concise description of your question.

## 📚 Context

Provide some context for your question. What are you trying to achieve?

## 🔍 What I've Tried

Describe what you've already tried to find an answer:

- [ ] Read the README
- [ ] Checked the documentation
- [ ] Searched existing issues
- [ ] Searched online

## 💻 Code Example (if applicable)

```typescript
// Your code here
```

## 📸 Screenshots (if applicable)

If applicable, add screenshots to help illustrate your question.

## 🌍 Environment

- **Vibely Version**: [e.g., 0.1.0]
- **Node.js Version**: [e.g., 18.17.0]
- **Browser**: [e.g., Chrome 120]

## 📋 Additional Context

Add any other context about your question here.

---

### Checklist

- [ ] I have searched the existing issues and discussions
- [ ] I have provided all relevant information
