---
name: Bug Report
about: Report a bug to help us improve Vibely
title: '[BUG] '
labels: bug, needs-triage
assignees: ''
---

## 🐛 Bug Description

A clear and concise description of what the bug is.

## 📋 Steps to Reproduce

Steps to reproduce the behavior:
1. Go to '...'
2. Click on '...'
3. Scroll down to '...'
4. See error

## ✅ Expected Behavior

A clear and concise description of what you expected to happen.

## ❌ Actual Behavior

A clear and concise description of what actually happened.

## 📸 Screenshots

If applicable, add screenshots to help explain your problem.

## 💻 Environment

Please complete the following information:

- **OS**: [e.g., macOS, Windows, Linux]
- **Browser**: [e.g., Chrome, Firefox, Safari]
- **Browser Version**: [e.g., 120.0]
- **Node.js Version**: [e.g., 18.17.0]
- **npm/yarn Version**: [e.g., npm 9.6.7]

## 📱 Device (if mobile)

- **Device**: [e.g., iPhone 14, Pixel 7]
- **OS Version**: [e.g., iOS 17, Android 14]

## 🔍 Additional Context

Add any other context about the problem here.

## 📝 Possible Solution

If you have suggestions on how to fix the bug, please describe them here.

---

### Checklist

- [ ] I have searched the existing issues to make sure this bug has not been reported
- [ ] I have provided all the requested information
- [ ] I am willing to help fix this bug (optional)
