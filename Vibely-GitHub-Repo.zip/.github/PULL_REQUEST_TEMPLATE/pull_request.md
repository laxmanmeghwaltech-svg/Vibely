## 📝 Description

<!--
Provide a clear and concise description of your changes.
What does this PR do? Why is it needed?
-->

## 🔗 Related Issue

<!--
Link to the issue this PR addresses.
Use keywords like "Fixes #123" or "Closes #456" to auto-close issues.
-->

Fixes #

## 📋 Type of Change

<!-- Mark the relevant option with an 'x' -->

- [ ] 🐛 Bug fix (non-breaking change which fixes an issue)
- [ ] ✨ New feature (non-breaking change which adds functionality)
- [ ] 💥 Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] 📚 Documentation update
- [ ] 🎨 Style/UI update
- [ ] ♻️ Code refactoring
- [ ] ⚡ Performance improvement
- [ ] ✅ Test addition/update
- [ ] 🔧 Configuration change

## 🧪 How Has This Been Tested?

<!--
Describe the tests you ran to verify your changes.
Include instructions for reviewers to reproduce.
-->

- [ ] Test A
- [ ] Test B

### Test Configuration

- **Node.js Version**: 
- **Browser**: 
- **OS**: 

## 📸 Screenshots

<!--
If applicable, add screenshots to help explain your changes.
You can use a table to show before/after comparisons.
-->

| Before | After |
|--------|-------|
| *screenshot* | *screenshot* |

## ✅ Checklist

<!-- Mark completed items with an 'x' -->

### Code Quality

- [ ] My code follows the style guidelines of this project
- [ ] I have performed a self-review of my own code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests pass locally with my changes

### Git

- [ ] My commits follow the [Conventional Commits](https://www.conventionalcommits.org/) specification
- [ ] I have rebased my branch on top of the latest main branch

### Documentation

- [ ] I have updated the README if necessary
- [ ] I have updated the CHANGELOG.md
- [ ] I have added/updated JSDoc comments for new functions

## 📌 Additional Notes

<!--
Add any additional notes or context about the PR here.
Are there any areas that need special attention?
Any known issues with this PR?
-->

## 🚀 Deployment Notes

<!--
Are there any deployment considerations?
Database migrations? Environment variables? etc.
-->

---

### Reviewer Guidelines

When reviewing this PR, please focus on:

1. **Code Quality**: Is the code clean, readable, and follows best practices?
2. **Functionality**: Does the change work as expected?
3. **Testing**: Are there adequate tests?
4. **Documentation**: Is the change properly documented?
5. **Breaking Changes**: Are there any breaking changes that need to be communicated?

---

**Thank you for your contribution! 🎉**
